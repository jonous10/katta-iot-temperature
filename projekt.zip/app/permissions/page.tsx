"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { usePermissions } from "@/hooks/usePermissions";
import Header from "../components/Header";

interface User {
  id: number;
  name: string;
  email: string;
  type: string;
  created_at?: string;
}

interface PermissionChange {
  userId: number;
  userName: string;
  oldType: string;
  newType: string;
  timestamp: string;
  changedBy: string;
}

export default function PermissionsPage() {
  const router = useRouter();
  const { isOwner, loading, userType } = usePermissions();
  const [users, setUsers] = useState<User[]>([]);
  const [currentUserId, setCurrentUserId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [updating, setUpdating] = useState<number | null>(null);
  const [recentChanges, setRecentChanges] = useState<PermissionChange[]>([]);

  useEffect(() => {
    if (!loading) {
      if (!isOwner()) {
        router.push("/");
        return;
      }
      fetchUsers();
    }
  }, [userType, loading, isOwner]);

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/users");
      const data = await res.json();

      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          router.push("/login");
          return;
        }
        throw new Error(data.error || "Failed to fetch users");
      }

      setUsers(data.users);
      setCurrentUserId(data.currentUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    }
  };

  const handleTypeChange = async (userId: number, newType: string) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;

    setUpdating(userId);
    try {
      const res = await fetch("/api/users", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, newType }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update user");

      // Update the user in the list
      setUsers(users.map((u) => (u.id === userId ? { ...u, type: newType } : u)));

      // Add to recent changes
      const change: PermissionChange = {
        userId,
        userName: user.name,
        oldType: user.type,
        newType,
        timestamp: new Date().toLocaleString(),
        changedBy: userType || "Unknown"
      };
      setRecentChanges(prev => [change, ...prev.slice(0, 9)]); // Keep last 10 changes

    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to update user");
    } finally {
      setUpdating(null);
    }
  };

  const handleDelete = async (userId: number, userName: string) => {
    if (!confirm(`Are you sure you want to delete ${userName}? This action cannot be undone.`)) return;

    try {
      const res = await fetch("/api/users", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete user");

      setUsers(users.filter((u) => u.id !== userId));

      // Add to recent changes
      const change: PermissionChange = {
        userId,
        userName,
        oldType: users.find(u => u.id === userId)?.type || "unknown",
        newType: "DELETED",
        timestamp: new Date().toLocaleString(),
        changedBy: userType || "Unknown"
      };
      setRecentChanges(prev => [change, ...prev.slice(0, 9)]);

    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to delete user");
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "owner": return "bg-purple-100 text-purple-800 border-purple-200";
      case "admin": return "bg-blue-100 text-blue-800 border-blue-200";
      case "viewer": return "bg-green-100 text-green-800 border-green-200";
      case "pending": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getAvailableTypes = () => ["pending", "viewer", "admin", "owner"];

  const getStats = () => {
    const stats = {
      total: users.length,
      owners: users.filter(u => u.type === 'owner').length,
      admins: users.filter(u => u.type === 'admin').length,
      viewers: users.filter(u => u.type === 'viewer').length,
      pending: users.filter(u => u.type === 'pending').length,
    };
    return stats;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-red-500">{error}</div>
      </div>
    );
  }

  const stats = getStats();

  return (
    <>
      <Header />


    </>
  );
}
